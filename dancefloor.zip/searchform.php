<div style="margin-bottom:40px;">
<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<div><input type="text" value="Enter keywords..." onfocus="if (this.value == 'Enter keywords...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Enter keywords...';}"  name="s" id="s" />
<input type="submit" id="searchsubmit" value="Search" />
</div>
</form>
</div>
