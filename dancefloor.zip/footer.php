 <div id="footOut">
 <div class="divider"></div>
	<div id="footIn">
    	   <div id="footer_ad">
		<?php FooterBanner(); ?>
	</div>
  	</div>
</div>
</div>
<div id="footer-bottom">
	<div id="copyright">
		<a href="http://gorillathemes.com"><?php echo get_bloginfo('name') ?></a> by Gorilla Themes - Локализация <a target="_blank" title="шаблоны wordpress" href="http://morestyle.ru/"><img src="http://favicon.yandex.net/favicon/morestyle.ru" alt="темы wordpress"/></a>
 	</div>
</div>
</div></div>
<style type="text/css">h1,h2,.menu a,.menu li a,.menu li a,.date_title .day,.date_title .month,.taghead,#show,#player .mejs-container,#player { visibility: visible; }</style>
<script type="text/javascript"> Cufon.now(); </script>
<?php wp_footer(); ?>
</body>
</html>